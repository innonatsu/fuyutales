package com.example.vidz4hire.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "file")
public class FileUploadProperties{
    private String dir;

    public String getUploadDir() {
        return dir;
    }

    public void setUploadDir(String dir) {
        this.dir = dir;
    }
}
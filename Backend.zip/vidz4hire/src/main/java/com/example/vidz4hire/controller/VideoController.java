package com.example.vidz4hire.controller;


import java.util.List;

import javax.validation.Valid;

import com.example.vidz4hire.model.Video;
import com.example.vidz4hire.repository.VideoRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class VideoController{
    @Autowired
    VideoRepository videoRepository;
    
    //@CrossOrigin(origins = "http://localhost:4200")
    @GetMapping("/videos")
    public List<Video> getAllVideos(){
        return videoRepository.findAll();
    } 

    //@CrossOrigin(origins = "http://localhost:4200")
    @PostMapping("/add")
    public Video createVideo(@Valid @RequestBody Video video){
        return videoRepository.save(video);
    }

    //@CrossOrigin(origins = "http://localhost:4200")
    @GetMapping("/videos/{id}")
    public Video getVideoById(@PathVariable(value = "id") Long videoId){    
        
        return videoRepository.findById(videoId)
            .orElseThrow(() -> new IllegalArgumentException("NOT FOUND"));
    }

    //@CrossOrigin(origins = "http://localhost:4200")
    @PostMapping("/videos/{id}")
    public Video updateVideo(@PathVariable(value = "id") Long videoId,
                                            @Valid @RequestBody Video videoDetails) {

        Video video = videoRepository.findById(videoId)
                .orElseThrow(() -> new IllegalArgumentException("NOT FOUND"));

        video.setName(videoDetails.getName());
        video.setCover(videoDetails.getCover());
        video.setGenre(videoDetails.getGenre());

        Video updatedVideo = videoRepository.save(video);
        return updatedVideo;
    }

    //@CrossOrigin(origins = "http://localhost:4200")
    @PostMapping("/remove/{id}")
    public ResponseEntity<?> deleteVideo(@PathVariable(value = "id") Long videoId) {
        Video video = videoRepository.findById(videoId)
        .orElseThrow(() -> new IllegalArgumentException("NOT FOUND"));

        videoRepository.delete(video);

        return ResponseEntity.ok().build();
    }
}
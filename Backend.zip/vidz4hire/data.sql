CREATE TABLE videos(
    id int not null PRIMARY KEY AUTO_INCREMENT,
    name text not null,
    cover text not null,
    genre text not null
);

